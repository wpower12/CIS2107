William Power
CIS2107 - HW02

Here are the programs I chose to implement.

 Section |   #  |     Filename     |
==================================== 
  switch |   5  |  evenoddswitch.c 
   loops |  30  | armstrongprint.c
   array |  26  |      swapdiags.c
   mixed |   1  |      charcount.c
   mixed |   7  |      	    dice.c
   mixed |  10  |          str2i.c
 
